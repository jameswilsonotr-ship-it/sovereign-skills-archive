# int10h Oldschool PC Font Suite (curated)

**Source:** [The Ultimate Oldschool PC Font Pack](https://int10h.org/oldschool-pc-fonts/) by **VileR**  
**License:** Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0) — see `LICENSE.TXT`  
**Pack version acquired:** v1.0 snapshot via Internet Archive (`ultimate_oldschool_pc_font_pack_v1.0`)  
**Note:** int10h.org live download is captcha-gated from this environment; Archive.org v1.0 is the verified open mirror used here. v2.2 adds more families/variants (Web437 woff, Mx, Ac) — grab manually when needed.

## Why these 18 faces

Selected for BBS / ANSI / NFO / SAUCE testing and board CSS:

| File | SAUCE / CSS family hint | Role |
|------|-------------------------|------|
| Px437_IBM_VGA8.ttf | IBM VGA / IBM VGA8 | **Primary** 8×16 VGA text mode |
| Px437_IBM_VGA9.ttf | IBM VGA9 | 9-dot wide VGA (sharper for some viewers) |
| Px437_IBM_EGA8.ttf | IBM EGA | 8×14 EGA |
| Px437_IBM_EGA9.ttf | IBM EGA9 | 9×14 EGA |
| Px437_IBM_CGA.ttf | IBM CGA | Classic 8×8 CGA |
| Px437_IBM_CGAthin.ttf | IBM CGAthin | Thin CGA variant |
| Px437_IBM_BIOS.ttf | IBM BIOS | System BIOS 8×8 |
| Px437_IBM_MDA.ttf | IBM MDA | Monochrome Display Adapter |
| Px437_Verite_8x16.ttf | Verite 8x16 | Rendition Verite — scene favorite |
| Px437_Verite_9x16.ttf | Verite 9x16 | Wide Verite |
| Px437_Phoenix_BIOS.ttf | Phoenix BIOS | Common clone BIOS |
| Px437_AMI_BIOS.ttf | AMI BIOS | Common clone BIOS |
| Px437_TandyNew_TV.ttf | Tandy TV | Tandy 1000 TV mode |
| Px437_Wyse700a.ttf | Wyse 700 | High-res terminal |
| Px437_ATI_8x16.ttf | ATI 8x16 | ATI VGA Wonder era |
| PxPlus_IBM_VGA8.ttf | IBM VGA (Plus) | Unicode-extended VGA8 for HTML |
| PxPlus_IBM_VGA9.ttf | IBM VGA9 (Plus) | Unicode-extended VGA9 |
| PxPlus_IBM_EGA8.ttf | IBM EGA (Plus) | Unicode-extended EGA8 |

**Px437** = CP437 / DOS Latin-US glyph set (correct for authentic NFO/ANSI).  
**PxPlus** = extended Unicode (Greek, Cyrillic, more Latin) for modern HTML boards.

## Already had (board root `fonts/`)

- `PxPlus_IBM_VGA8.ttf` (duplicate of Plus above — keep both paths stable)
- `VT323.ttf` (Google Fonts OFL — modern pixel)
- `ShareTechMono-Regular.ttf` (OFL fallback)

## SAUCE `font_name` examples

```text
IBM VGA
IBM VGA8
IBM VGA9
IBM EGA
IBM CGA
IBM BIOS
IBM MDA
Verite 8x16
Phoenix BIOS
AMI BIOS
```

Pass via `sauce_writer.py --font "IBM VGA9"` etc.
