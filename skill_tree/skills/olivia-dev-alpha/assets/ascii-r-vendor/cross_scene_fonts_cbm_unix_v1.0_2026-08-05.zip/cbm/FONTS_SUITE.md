# CBM font bank (Commodore)

**Source:** [zeiche/c64font](https://github.com/zeiche/c64font) — **CC0**  
**Glyphs:** PETSCII-style C64 character set (upper/graphics + lower variants)

| File | Role |
|------|------|
| c64.ttf / c64.otf | Standard C64 face |
| c64-shift.ttf | Shifted / alternate PETSCII mapping |
| c64-commodore.ttf | Commodore-key glyph set |

C128 80-col VDC face: not shipped as TTF here (ROM-only on Zimmers). Can be added later if a clean CC0 conversion appears.

Use for HTML board modes and conversational A/B vs IBM VGA — not as default SAUCE FontName (SAUCE is PC/ANSI-oriented).
