# Unix / terminal font bank

| File | Source | License | Role |
|------|--------|---------|------|
| 3270-Regular.ttf | [rbanffy/3270font](https://github.com/rbanffy/3270font) | See LICENSE.txt | IBM 3270 terminal |
| 3270SemiCondensed-Regular.ttf | same | same | Condensed 3270 |
| 3270Condensed-Regular.ttf | same | same | More condensed |
| x11-bdf/*.bdf | [ucs-fonts](https://www.cl.cam.ac.uk/~mgk25/ucs-fonts.html) | MIT-style X11 | Classic `fixed` family (6x13, 8x13, 9x15, 10x20) |

**Terminus:** deferred this pass (download mirrors 403/404 from this environment). Add SIL OFL Terminus TTF when available — preferred Unix workhorse sizes 8×16 / 10×18.

HTML/CSS family names for testing: `IBM 3270`, `3270 SemiCondensed`, `X11 Fixed`.
